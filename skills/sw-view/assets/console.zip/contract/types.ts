// Generated from skills/_shared/scripts/kitlib/dataformat.py. Do not edit.

export const FORMAT = "specwright-data";
export const FORMAT_VERSION = 1;

export interface Envelope {
  format: string;
  formatVersion: number;
  kind: string;
  scope: string;
  owner: string;
  kit: string;
  inputsDigest: string | null;
  banner: string;
}

export interface IndexFile {
  owner: string;
  sha256: string;
  bytes: number;
  rows: number;
  inputsDigest: string | null;
}

export interface DataIndex extends Envelope {
  files: Record<string, IndexFile>;
  idleAfterDays: number;
  layout: string | null;
  mode: string;
  scopes: string[];
  digest: string;
}

export interface FeaturesRow {
  "id": string;
  "scope": string;
  "title": string;
  "state": string;
  "station": string | null;
  "condition": string | null;
  "blockers": string[];
  "lint": string | null;
  "illustration": string | null;
  "jira": string | null;
  "drift": string | null;
  "openQuestions": string[];
  "openChanges": string[];
  "signoff": string | null;
  "updated": string | null;
  "snapshotDate": string | null;
  "next": string | null;
  "turn": string | null;
  "bo": string[];
  "acCount": number;
  "taskCount": number;
  "path": string | null;
  "line": number;
}

export interface FeaturesData extends Envelope {
  rows: FeaturesRow[];
}

export interface GraphNode {
  "key": string;
  "kind": string;
  "status": string | null;
  "title": string;
  "scope": string | null;
  "path": string | null;
  "line": number;
  "jira": string | null;
  "aliases": string[];
  "station": string | null;
  "condition": string | null;
}

export interface GraphEdge {
  "from": string;
  "rel": "member_of" | "realizes" | "governed_by" | "sourced_from" | "shaped_from" | "source_parent" | "has_ac" | "has_task" | "implements" | "touches" | "affects" | "supersedes" | "illustrates" | "exercises" | "derives_from" | "published_as" | "last_snapshot" | "external_parent" | "blocks" | "mentions";
  "to": string;
  "class": "declared" | "structural" | "registry" | "mentioned";
  "file": string | null;
  "line": number;
  "resolution": "resolved" | "unresolved" | "withdrawn" | "scope-not-loaded" | "external" | "exists" | "missing" | null;
}

export interface GraphData extends Envelope {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface QualityResult {
  "scope": string;
  "id": string;
  "result": string | null;
}

export interface QualityFinding {
  "scope": string;
  "rule": string;
  "severity": string | null;
  "subject": string | null;
  "location": string | null;
  "waived": boolean;
}

export interface QualityData extends Envelope {
  results: QualityResult[];
  findings: QualityFinding[];
  gates: string[];
}

export interface RecordsRow {
  "id": string;
  "kind": string;
  "scope": string;
  "title": string;
  "status": string | null;
  "affects": string[];
  "updated": string | null;
  "path": string | null;
  "line": number;
}

export interface RecordsData extends Envelope {
  rows: RecordsRow[];
}

export interface RegistryRow {
  "id": string;
  "scope": string;
  "kind": string | null;
  "jiraKey": string | null;
  "confluenceId": string | null;
  "label": string | null;
  "state": string | null;
  "title": string | null;
  "aliases": string[];
  "sourceRef": string | null;
  "lastSnapshot": string | null;
}

export interface RegistryData extends Envelope {
  rows: RegistryRow[];
}

export interface RtmRow {
  "id": string;
  "scope": string;
  "bo": string | null;
  "brNfr": string | null;
  "storyDraft": string | null;
  "jira": string | null;
  "jiraStatus": string | null;
  "signoff": string | null;
  "drift": string | null;
  "testRef": string | null;
}

export interface RtmData extends Envelope {
  rows: RtmRow[];
}

export interface ScopesRow {
  "scope": string;
  "name": string;
  "jiraProjectKey": string | null;
  "features": number;
  "acs": number;
  "tasks": number;
  "records": number;
  "sources": number;
  "gate": string | null;
}

export interface ScopesData extends Envelope {
  rows: ScopesRow[];
}

export interface SourcesRow {
  "id": string;
  "kind": string;
  "scope": string;
  "title": string;
  "status": string | null;
  "fetchedAt": string | null;
  "path": string | null;
}

export interface SourcesData extends Envelope {
  rows: SourcesRow[];
}

export interface TasksRow {
  "id": string;
  "feature": string;
  "scope": string;
  "title": string;
  "status": "active" | "withdrawn";
  "traces": string[];
  "touches": string | null;
  "path": string | null;
  "line": number;
}

export interface TasksData extends Envelope {
  rows: TasksRow[];
}

export interface DataKinds {
  features: FeaturesData;
  graph: GraphData;
  quality: QualityData;
  records: RecordsData;
  registry: RegistryData;
  rtm: RtmData;
  scopes: ScopesData;
  sources: SourcesData;
  tasks: TasksData;
}

export type KindName = keyof DataKinds;

export const OWNERS: Record<string, string> = {
  features: "sw-start",
  graph: "sw-start",
  quality: "sw-review",
  records: "sw-shape",
  registry: "sw-spec",
  rtm: "sw-plan",
  scopes: "sw-start",
  sources: "sw-ingest",
  tasks: "sw-plan",
};

export const RELATIONS = ["member_of", "realizes", "governed_by", "sourced_from", "shaped_from", "source_parent", "has_ac", "has_task", "implements", "touches", "affects", "supersedes", "illustrates", "exercises", "derives_from", "published_as", "last_snapshot", "external_parent", "blocks", "mentions"] as const;
