import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import type { GraphEdge, GraphNode } from '../contract/types';
import { BOX, buildTrace, chainOf, focusModel, traceCoverage } from '../src/lib/graph/trace';
import { read, type Variant } from './golden';

function load(variant: Variant): { nodes: GraphNode[]; edges: GraphEdge[] } {
  const doc = JSON.parse(read(variant, 'data/graph.json'));
  return { nodes: doc.nodes, edges: doc.edges };
}

const { nodes, edges } = load('trace');
const jira = new Map(
  (JSON.parse(read('trace', 'data/registry.json')).rows as { id: string; jiraKey: string | null }[]).filter((r) => r.jiraKey).map((r) => [r.id, r.jiraKey as string]),
);
const model = buildTrace(nodes, edges, { code: true, jira });
const plain = buildTrace(nodes, edges, { jira });
const byKey = (key: string) => model.nodes.find((n) => n.key === key)!;
const gaps = () => model.nodes.filter((n) => n.gap).map((n) => `${n.gap}:${n.id.split(':').slice(2).join(':')}`).sort();

describe('the trace map lays the chain out from why to how', () => {
  it('puts each kind in its own column, left to right', () => {
    expect(model.levels).toEqual([0, 1, 2, 3, 4, 5]);
    const xs = (kind: string) => new Set(model.nodes.filter((n) => n.kind === kind && !n.gap).map((n) => n.x));
    for (const kind of ['bo', 'epic', 'feat', 'ac', 'task', 'code']) expect(xs(kind).size, kind).toBe(1);
    expect([...xs('bo')][0]).toBeLessThan([...xs('epic')][0]);
    expect([...xs('ac')][0]).toBeLessThan([...xs('task')][0]);
    expect([...xs('task')][0]).toBeLessThan([...xs('code')][0]);
  });

  it('draws only links the data holds, each from the lower level to the higher one', () => {
    const real = model.links.filter((l) => !l.gap);
    expect(real.every((l) => byKey(l.left).level < byKey(l.right).level)).toBe(true);
    const sentence = (text: string) => real.some((l) => l.sentence === text);
    expect(sentence('Submit a refund request belongs to epic Self-service refunds')).toBe(true);
    expect(sentence('Submit a refund request serves business objective Reduce refund waiting time')).toBe(true);
    expect(sentence('[backend] Refuse a duplicate implements Duplicate request')).toBe(true);
    expect(real.filter((l) => l.rel === 'implements')).toHaveLength(5);
    expect(real.filter((l) => l.rel === 'has_ac')).toHaveLength(5);
  });

  it('stops at tasks unless code files are asked for', () => {
    expect(plain.levels).toEqual([0, 1, 2, 3, 4]);
    expect(plain.nodes.some((n) => n.kind === 'code')).toBe(false);
    expect(model.nodes.filter((n) => n.kind === 'code').map((n) => n.title)).toEqual(['src/decide.py', 'src/notify.py', 'src/refund.py']);
  });

  it('shows a Jira issue on the card of any item the registry gives one, never as a node', () => {
    expect(byKey('REF:FEAT-001').jira).toBe('PROJ-101');
    expect(byKey('REF:EPIC-001').jira).toBe('PROJ-100');
    expect(byKey('REF:FEAT-002').jira).toBeNull();
    expect(model.nodes.some((n) => n.kind === 'jira')).toBe(false);
  });

  it('never gives a task a Jira key: tasks stay in Markdown', () => {
    expect(model.nodes.filter((n) => n.kind === 'task').every((n) => n.jira === null)).toBe(true);
  });

  it('shows every missing link as a placeholder that names the skill to ask', () => {
    expect(gaps()).toEqual([
      'epic-bo:REF:EPIC-002',
      'epic:REF:FEAT-003',
      'task-criterion:REF:TASK-001-3',
      'task:REF:AC-003-2',
    ]);
    const epic = model.nodes.find((n) => n.id === 'gap:epic:REF:FEAT-003')!;
    expect([epic.title, epic.next, epic.level]).toEqual(['No epic yet', 'sw-craft', 1]);
    expect(model.nodes.find((n) => n.id === 'gap:task:REF:AC-003-2')!.next).toBe('sw-forge');
    const bare = model.nodes.find((n) => n.id === 'gap:epic-bo:REF:EPIC-002')!;
    expect([bare.title, bare.next, bare.level]).toEqual(['No business objective', 'sw-craft', 0]);
  });

  it('lists a reference to something nobody defined', () => {
    expect(model.broken.map((b) => b.sentence)).toEqual(['Decide a refund request mentions FEAT-009, which is not defined anywhere']);
  });

  it('measures how complete the chain is', () => {
    const cover = Object.fromEntries(traceCoverage(nodes, edges).map((c) => [c.id, [c.have, c.total, c.gaps]]));
    expect(cover).toEqual({
      epic: [2, 3, ['REF:FEAT-003']],
      bo: [3, 3, []],
      'epic-bo': [1, 2, ['REF:EPIC-002']],
      ac: [3, 3, []],
      covered: [4, 5, ['REF:AC-003-2']],
      tied: [4, 5, ['REF:TASK-001-3']],
    });
  });

  it('follows the whole chain up and down from any item', () => {
    const criterion = chainOf(model, 'REF:AC-001-2').nodes;
    for (const key of ['REF:FEAT-001', 'REF:EPIC-001', 'REF:BO-001', 'REF:TASK-001-2', 'REF:code/src/notify.py']) expect(criterion.has(key), key).toBe(true);
    expect(criterion.has('REF:FEAT-002')).toBe(false);
    const feature = chainOf(model, 'REF:FEAT-003').nodes;
    expect(feature.has('gap:epic:REF:FEAT-003')).toBe(true);
    expect(feature.has('REF:BO-002')).toBe(true);
  });

  it('is deterministic and never overlaps two items in a column', () => {
    expect(JSON.stringify(buildTrace(nodes, edges, { code: true, jira }))).toBe(JSON.stringify(model));
    const seen = new Set<string>();
    for (const n of model.nodes) {
      const at = `${n.x},${n.y}`;
      expect(seen.has(at), at).toBe(false);
      seen.add(at);
    }
    expect(model.height).toBeGreaterThanOrEqual(BOX.top + BOX.h);
  });

  it('can keep just one chain when the map is too large to read whole', () => {
    const slim = focusModel(nodes, edges, 'REF:AC-003-1');
    const keys = slim.nodes.map((n) => n.id);
    expect(keys).toContain('REF:AC-003-2');
    expect(keys).toContain('REF:BO-002');
    expect(keys).not.toContain('REF:FEAT-001');
  });

  it('says so when a level does not exist yet instead of drawing placeholders for all', () => {
    const flat = load('flat');
    const sparse = buildTrace(flat.nodes, flat.edges);
    expect(sparse.notes).toEqual(['No epic is defined, so features are shown without one.', 'No task is planned yet, so criteria are shown without tasks.']);
    expect(sparse.nodes.filter((n) => n.gap).map((n) => n.gap)).toEqual(['bo']);
    expect(traceCoverage(flat.nodes, flat.edges).map((c) => c.id)).toEqual(['bo', 'ac']);
  });
});

describe('an epic serves business objectives and its features inherit them', () => {
  const real = model.links.filter((l) => !l.gap);
  const between = (rel: string, from: string, to: string) => real.find((l) => l.rel === rel && l.id === `${from}|${rel}|${to}`);

  it('draws the epic to its objective', () => {
    const link = between('realizes', 'REF:EPIC-001', 'REF:BO-001')!;
    expect(link.implied).toBe(false);
    expect(byKey('REF:BO-001').level).toBeLessThan(byKey('REF:EPIC-001').level);
  });

  it('hides a feature\'s own link to an objective its epic already serves', () => {
    expect(between('realizes', 'REF:FEAT-001', 'REF:BO-001')!.implied).toBe(true);
    expect(between('realizes', 'REF:FEAT-003', 'REF:BO-002')!.implied).toBe(false);
  });

  it('still lights the feature from the objective', () => {
    const chain = chainOf(model, 'REF:BO-001').nodes;
    for (const key of ['REF:EPIC-001', 'REF:FEAT-001', 'REF:FEAT-002', 'REF:AC-001-2']) expect(chain.has(key), key).toBe(true);
  });

  it('counts a feature as serving an objective through its epic', () => {
    const cover = traceCoverage(nodes, edges).find((c) => c.id === 'bo')!;
    expect(cover.gaps).not.toContain('REF:FEAT-002');
  });

  it('keeps an epic with no objective visible as a gap, next to the objective column', () => {
    const gap = model.nodes.find((n) => n.id === 'gap:epic-bo:REF:EPIC-002')!;
    expect(gap.level).toBe(0);
    const link = model.links.find((l) => l.right === 'REF:EPIC-002' && l.gap)!;
    expect(link.left).toBe(gap.id);
  });
});

describe('reading an item is the eye, not the card', () => {
  const source = readFileSync(new URL('../src/components/TraceMap.svelte', import.meta.url), 'utf8');
  it('puts an eye on each card that calls onview, and makes choosing the card only select it', () => {
    expect(source).toMatch(/class="eye"[^>]*aria-label=\{`View /);
    expect(source).toContain('onview(n.key!)');
    expect(source).toMatch(/class="card"[\s\S]*onclick=\{\(\) => onselect\(/);
    expect(source).not.toMatch(/onclick=\{\(\) => onview/);
  });
});

describe('the card stripe follows the card corners', () => {
  const source = readFileSync(new URL('../src/components/TraceMap.svelte', import.meta.url), 'utf8');
  it('clips the stripe to the rounded card and draws the border over it', () => {
    expect(source).toContain('<clipPath id="trace-card-clip">');
    expect(source).toMatch(/class="bar"[^>]*clip-path="url\(#trace-card-clip\)"/);
    expect(source.indexOf('class="bar"')).toBeLessThan(source.indexOf('class="card-edge"'));
  });
});

describe('criteria and tasks fold under their feature', () => {
  const folded = buildTrace(nodes, edges, { jira, expand: new Set() });
  const opened = buildTrace(nodes, edges, { jira, expand: new Set(['REF:FEAT-001']) });
  const kinds = (m: typeof folded) => m.nodes.filter((n) => !n.gap).map((n) => n.kind);

  it('draws no criterion or task until a feature is open', () => {
    expect(kinds(folded).filter((k) => k === 'ac' || k === 'task')).toEqual([]);
    expect(folded.levels).toEqual([0, 1, 2]);
    expect(folded.hidden).toBe(10);
    expect(folded.nodes.filter((n) => n.gap && n.level >= 3)).toEqual([]);
    expect(folded.links.every((l) => folded.nodes.some((n) => n.id === l.left) && folded.nodes.some((n) => n.id === l.right))).toBe(true);
  });

  it('keeps the counts and the open work on the folded feature card', () => {
    const feature = (key: string) => folded.nodes.find((n) => n.key === key)!;
    expect(feature('REF:FEAT-001').below).toEqual({ ac: 2, task: 3, open: 1 });
    expect(feature('REF:FEAT-001').open).toBe(false);
    expect(plain.nodes.filter((n) => n.gap).length).toBeGreaterThan(0);
    const open = (key: string) => feature(key).below!.open;
    expect(['REF:FEAT-001', 'REF:FEAT-002', 'REF:FEAT-003'].map(open)).toEqual([1, 0, 1]);
  });

  it('opens only the chosen feature, with its own criteria and tasks beside it', () => {
    const own = opened.nodes.filter((n) => !n.gap && (n.kind === 'ac' || n.kind === 'task')).map((n) => n.key).sort();
    expect(own).toEqual(['REF:AC-001-1', 'REF:AC-001-2', 'REF:TASK-001-1', 'REF:TASK-001-2', 'REF:TASK-001-3']);
    expect(opened.nodes.find((n) => n.key === 'REF:FEAT-001')!.open).toBe(true);
    expect(opened.nodes.find((n) => n.key === 'REF:FEAT-002')!.open).toBe(false);
    expect(opened.hidden).toBe(5);
    expect(chainOf(opened, 'REF:FEAT-001').nodes.has('REF:TASK-001-3')).toBe(true);
  });

  it('draws everything by default and the same cards as before', () => {
    expect(JSON.stringify(buildTrace(nodes, edges, { jira, expand: 'all' }))).toBe(JSON.stringify(plain));
    expect(plain.hidden).toBe(0);
    expect(plain.nodes.find((n) => n.key === 'REF:FEAT-001')!.open).toBe(true);
  });

  it('puts an open feature level with its criteria and keeps groups apart', () => {
    const feature = opened.nodes.find((n) => n.key === 'REF:FEAT-001')!;
    const criteria = opened.nodes.filter((n) => n.kind === 'ac');
    const middle = criteria.reduce((sum, n) => sum + n.y, 0) / criteria.length;
    expect(Math.abs(middle - feature.y)).toBeLessThanOrEqual(BOX.h + BOX.gapY);
    for (const column of [3, 4]) {
      const ys = opened.nodes.filter((n) => n.level === column).map((n) => n.y).sort((a, b) => a - b);
      ys.slice(1).forEach((y, i) => expect(y - ys[i]).toBeGreaterThanOrEqual(BOX.h + BOX.gapY));
    }
    expect(opened.height).toBeGreaterThan(feature.y);
  });

  it('stays small when there are thousands of criteria', () => {
    const many: GraphNode[] = [];
    const links: GraphEdge[] = [];
    const base = nodes.find((n) => n.key === 'REF:FEAT-001')!;
    for (let f = 0; f < 200; f++) {
      many.push({ ...base, key: `REF:FEAT-${String(f).padStart(3, '0')}`, title: `Feature ${f}` });
      for (let a = 0; a < 10; a++) {
        const key = `REF:AC-${f}-${a}`;
        many.push({ ...base, key, kind: 'ac', title: key });
        links.push({ from: `REF:FEAT-${String(f).padStart(3, '0')}`, rel: 'has_ac', to: key, class: 'declared', file: 'x', line: 1, resolution: 'resolved' });
      }
    }
    const folded = buildTrace(many, links, { expand: new Set() });
    expect(folded.nodes.filter((n) => n.kind === 'ac')).toHaveLength(0);
    expect(folded.hidden).toBe(2000);
    expect(folded.nodes.filter((n) => n.kind === 'feat')).toHaveLength(200);
    const one = buildTrace(many, links, { expand: new Set(['REF:FEAT-100']) });
    expect(one.nodes.filter((n) => n.kind === 'ac')).toHaveLength(10);
    expect(one.nodes.find((n) => n.key === 'REF:FEAT-100')!.below).toEqual({ ac: 10, task: 0, open: 0 });
  });
});
